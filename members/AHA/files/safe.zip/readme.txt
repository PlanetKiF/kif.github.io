 Instructions:
 -------------
 
 Simple unzip all these files into your cstrike directory, make sure 'Use Folder Names' is checked (in winzip).. Run enable.bat [which replaces the problematic .mdl files with this unproblematic safe.mdl]

It [the crash model cheat] won't crash other people that have it (goodie) so like, yea.
